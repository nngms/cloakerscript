-- MySQL dump 10.13  Distrib 5.7.33, for Linux (x86_64)
--
-- Host: localhost    Database: cixpanel_clock
-- ------------------------------------------------------
-- Server version	5.7.33

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Current Database: `cixpanel_clock`
--


--
-- Table structure for table `links`
--

DROP TABLE IF EXISTS `links`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `links` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `source` varchar(255) NOT NULL,
  `target` text NOT NULL,
  `random` int(11) NOT NULL DEFAULT '0',
  `redirect_type` varchar(40) NOT NULL,
  `hits` int(11) NOT NULL DEFAULT '0',
  `last_hit` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `user_id` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `links`
--

LOCK TABLES `links` WRITE;
/*!40000 ALTER TABLE `links` DISABLE KEYS */;
INSERT INTO `links` (`id`, `source`, `target`, `random`, `redirect_type`, `hits`, `last_hit`, `user_id`) VALUES (14,'adsdeneme','http://test.net/',0,'adwords',14,'2021-04-02 21:44:25',0);
/*!40000 ALTER TABLE `links` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `order_invoice`
--

DROP TABLE IF EXISTS `order_invoice`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `order_invoice` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `order_id` int(11) DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  `total` double DEFAULT NULL,
  `payment_method` int(11) DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  `approve` int(11) DEFAULT NULL,
  `package_id` int(11) NOT NULL DEFAULT '0',
  `package_name` varchar(255) CHARACTER SET utf8 DEFAULT NULL,
  `link_count` int(11) NOT NULL DEFAULT '0',
  `created_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `order_invoice`
--

LOCK TABLES `order_invoice` WRITE;
/*!40000 ALTER TABLE `order_invoice` DISABLE KEYS */;
INSERT INTO `order_invoice` (`id`, `order_id`, `user_id`, `total`, `payment_method`, `status`, `approve`, `package_id`, `package_name`, `link_count`, `created_at`) VALUES (1,NULL,2,35,1,0,NULL,1,'Ba?lang?',1,'2021-04-02 21:42:38'),(2,NULL,3,35,1,0,NULL,1,'Başlangıç',1,'2021-04-02 22:21:02'),(3,NULL,2,35,1,0,NULL,1,'Başlangıç',1,'2021-04-02 22:55:39'),(4,NULL,3,35,1,0,NULL,1,'Başlangıç',1,'2021-04-15 18:32:56'),(5,NULL,3,60,1,0,NULL,2,'Profesyonel',3,'2021-04-15 18:38:48'),(6,NULL,3,35,1,0,NULL,1,'Başlangıç',1,'2021-04-15 18:59:38');
/*!40000 ALTER TABLE `order_invoice` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `packages`
--

DROP TABLE IF EXISTS `packages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `packages` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) DEFAULT NULL,
  `price` varchar(40) NOT NULL,
  `link_count` int(11) NOT NULL DEFAULT '0',
  `properties` text,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `packages`
--

LOCK TABLES `packages` WRITE;
/*!40000 ALTER TABLE `packages` DISABLE KEYS */;
INSERT INTO `packages` (`id`, `name`, `price`, `link_count`, `properties`) VALUES (1,'Başlangıç','35',1,NULL),(2,'Profesyonel','60',3,NULL),(3,'Sosyal Medya Paketi','50',2,NULL);
/*!40000 ALTER TABLE `packages` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `settings`
--

DROP TABLE IF EXISTS `settings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `settings` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `value` text NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `settings_name_unique` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=34 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `settings`
--

LOCK TABLES `settings` WRITE;
/*!40000 ALTER TABLE `settings` DISABLE KEYS */;
INSERT INTO `settings` (`id`, `name`, `value`, `created_at`, `updated_at`) VALUES (6,'title','site.com',NULL,'2018-02-22 13:35:38'),(7,'description','desc',NULL,'2018-02-22 13:35:38'),(8,'keywords','keywords',NULL,'2017-12-29 07:26:38'),(15,'uye_aktivasyon_turu','0',NULL,NULL),(16,'enable_registration','1',NULL,'2018-02-22 13:35:38'),(17,'mail_host','mail.cixpanel.com',NULL,'2018-01-04 10:00:58'),(18,'mail_address','info@cixpanel.com',NULL,'2018-01-04 10:00:58'),(19,'mail_pass','italyanherif!07',NULL,'2018-01-04 10:00:58'),(20,'mail_port','465',NULL,'2018-01-04 10:00:58'),(21,'mail_secure','tls',NULL,'2018-01-04 10:00:58'),(22,'notify_mail','info@cixpanel.com',NULL,'2018-01-04 10:00:58'),(23,'notify_sms','',NULL,'2018-01-04 10:00:58'),(27,'api_commission','7',NULL,NULL),(28,'footer_code','',NULL,NULL),(29,'contact_mail','iletisim@seora.net',NULL,NULL),(30,'contact_phone','541 964 50 24',NULL,NULL),(31,'contact_skype','ogulcan.444',NULL,NULL),(32,'title2','Medya<i>Panel</i><span>.com</span>',NULL,NULL),(33,'dashboard_1','Düzenli olarak otolike siparişi veren müşterilerimize özel indirim uygulanacaktır.\r\nBitiş Mart 30, 2018\r\nTarihine kadar bu indirimlerden yararlanabilirsiniz.!\r\nDüzenli satın alımlarda sürekli indirim uygulanacaktır.',NULL,NULL);
/*!40000 ALTER TABLE `settings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `users` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `email` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `permissions` text,
  `activated` tinyint(1) NOT NULL DEFAULT '0',
  `activation_code` varchar(255) DEFAULT NULL,
  `activated_at` timestamp NULL DEFAULT NULL,
  `last_login` timestamp NULL DEFAULT NULL,
  `persist_code` varchar(255) DEFAULT NULL,
  `reset_password_code` varchar(255) DEFAULT NULL,
  `first_name` varchar(255) DEFAULT NULL,
  `last_name` varchar(255) DEFAULT NULL,
  `phoneCountry` varchar(255) DEFAULT NULL,
  `phoneNumber` varchar(255) DEFAULT NULL,
  `balance` decimal(20,6) NOT NULL DEFAULT '0.000000',
  `api_key` varchar(255) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `users_email_unique` (`email`),
  KEY `users_activation_code_index` (`activation_code`),
  KEY `users_reset_password_code_index` (`reset_password_code`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` (`id`, `email`, `password`, `permissions`, `activated`, `activation_code`, `activated_at`, `last_login`, `persist_code`, `reset_password_code`, `first_name`, `last_name`, `phoneCountry`, `phoneNumber`, `balance`, `api_key`, `created_at`, `updated_at`) VALUES (1,'cloak_12@ad.min','$2y$10$rCE7fO5SWPgTs3Pbv69CMOrohnR6B2Vv7Qiw.30ZM.WGtI5VWcwnC','{\"superuser\":1}',1,NULL,'2017-05-23 02:00:12','2019-02-21 20:45:33','Z0lfhx8hSm1r0ffk0dOTEMDlQAPM2jojsWS5E65Vkl','V4z9duSKtj','oğulcan','değdaş','90','5419645024',20.000000,'013b10d0737715be64c480ff2058b6c4','2017-05-23 02:00:12','2019-02-21 20:45:33'),(2,'ogulcan.444@hotmail.com','$2y$10$R8clC36ECWwshVln./YFM.KUcpVHQAmW.QcSx0csVv.SwJdPQmoIe',NULL,1,NULL,NULL,NULL,NULL,NULL,'oğulcan','değdaş','+90','0541 964 5024',0.000000,NULL,'2021-03-29 10:48:16','2021-03-29 10:48:16'),(3,'nurettinnazlier@hotmail.it','$2y$10$0bT5EqniZl7X6sTvDhy6HuBFnt48n3d3ycwAlRZt2fGaJ6FGCqs12',NULL,1,NULL,NULL,NULL,NULL,NULL,'Nurettin','Nazlıer','+90','(538) 287 98 44',0.000000,NULL,'2021-04-02 19:20:41','2021-04-02 19:20:41');
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping events for database 'cixpanel_clock'
--

--
-- Dumping routines for database 'cixpanel_clock'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2021-04-20 18:46:50
