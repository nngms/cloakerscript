<?php

require '../panel/system/library/db.php';
function get_ip(){
    if(getenv("HTTP_CLIENT_IP")) {
        $ip = getenv("HTTP_CLIENT_IP");
    } elseif(getenv("HTTP_X_FORWARDED_FOR")) {
        $ip = getenv("HTTP_X_FORWARDED_FOR");
        if (strstr($ip, ',')) {
            $tmp = explode (',', $ip);
            $ip = trim($tmp[0]);
        }
    } else {
        $ip = getenv("REMOTE_ADDR");
    }
    return $ip;
}
function get_country(){
    $curl = curl_init();

    curl_setopt_array($curl, array(
        CURLOPT_URL => "https://freegeoip.app/json/".get_ip(),
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_ENCODING => "",
        CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
        CURLOPT_CUSTOMREQUEST => "GET",
        CURLOPT_HTTPHEADER => array(
            "accept: application/json",
            "content-type: application/json"
        ),
    ));

    $response = curl_exec($curl);
    $err = curl_error($curl);

    curl_close($curl);

    preg_match('@country_code":"(.*?)"@', $response, $o);
    return $o[1];

}

$hostName = $_SERVER['HTTP_HOST'];
$name = explode('.',$hostName)[0];


$contry=get_country();
$available_countries = ['TR'];

$referer_domain = parse_url($_SERVER['HTTP_REFERER'], PHP_URL_HOST);
$platforms = ['google','facebook','instagram','twitter.com','pinterest','t.co','fb.me'];

$item = st('links', ['source'=>$name]);
if(!$item) return false;

qy('update links set hits = hits + 1, last_hit = ? where id = ?', [date('Y-m-d H:i:s'), $item->id]);

if($item->random==1){
    $urls = explode("\n", $item->target);
    $item->target = $urls[mt_rand(0,count($urls)-1)];
}


/**
 * Redirect Types
 */
if($item->redirect_type=='adwords'){

    foreach ($platforms as $platform) {
        if(in_array($contry, $available_countries) && preg_match('@'.$platform.'@',$referer_domain)){
            $redirect = 1;
        }
    }
    if(!$redirect) $item->target = '#';

    $template = file_get_contents('template.html');
    $template = str_replace('{{ url }}', $item->target, $template);
    echo $template;
    exit;

}else if($item->redirect_type=='social'){
    foreach ($platforms as $platform) {
        if(in_array($contry, $available_countries) && preg_match('@'.$platform.'@',$referer_domain)){
            $redirect = 1;
        }
    }
    if(!$redirect) $item->target = '#';
    $template = file_get_contents('template.html');
    $template = str_replace('{{ url }}', $item->target, $template);
    echo $template;
    exit;
}else if($item->redirect_type=='iframe'){

}else if($item->redirect_type=='no_redirect'){
    $template = file_get_contents('template.html');
    $template = str_replace('{{ url }}', '#', $template);
    echo $template;
    exit;
}else if($item->redirect_type=='js'){
    $template = file_get_contents('template.html');
    $template = str_replace('{{ url }}', $item->target, $template);
    echo $template;
    exit;
}else
    redirect($item->target,$item->redirect_type);


function redirect($php,$status=301) {
    if(!headers_sent()) {
        header("Location: ".$php, true, $status);
    } else {
        echo '<meta http-equiv="refresh" content="0;URL='.$php.'">';
    }
    exit();
}



