<?php
namespace Ctr;

class changePass extends base {

    public function index(){
        $vars=[];

        return render('changePass',$vars);
    }

    public function Save(){
        $creds = p();
        if(!$this->app->userLib->findByCredentials([
            'id'=>$this->app->user->id,
            'password'=>$creds['currentPassword']
        ]) )
            return json_encode(['error'=>'Şuanki şifreniz hatalı!']);

        $creds['id']=$this->app->user->id;
        unset($creds['currentPassword']);unset($creds['repeatPassword']);
        if(!$creds['password'])
            unset($creds['password']);
        $this->app->userLib->save($creds);

        return json_encode(['title'=>'Başarılı!','success'=>'Şifre Güncellendi.']);
    }

}
