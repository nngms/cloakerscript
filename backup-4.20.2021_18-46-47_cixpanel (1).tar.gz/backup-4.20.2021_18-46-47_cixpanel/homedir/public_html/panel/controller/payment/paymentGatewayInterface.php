<?php
namespace Ctr\payment;
interface paymentGatewayInterface {
    public function processPayment();
    public function authorize();
}