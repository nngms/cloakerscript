<?php
namespace Ctr\payment;

class paymentGateway extends \Ctr\base implements paymentGatewayInterface {

    public function __construct(){
        parent::__construct();
        $this->method = p('method') ? p('method'):g('id');
        $this->method = 'shopier';
//        $this->account = json_decode(st('payment_methods', ['code'=>$this->method])->account);
        $this->account = (object)['shopier_key'=>'b36df3637a4278526b49dcde060f3d0a','shopier_secret'=>'6a81c3ca780b974710d30f0b3131a8a1'];
    }

    public function processPayment(){
        $method = $this->method;
        if(file_exists(__DIR__.'/'.$method.'.php')){
            $name = 'Ctr\payment\\'.$method;
            $payment = new $name();
            $payment->notify();
        }else{
            return false;
        }


        \functions::sendMail('Bakiye Yükleme!',$this->app->settings->notify_mail,'Bakiye Yüklendi: '.$this->app->user->first_name.' - '.$this->app->user->phoneNumber);

        redirect($this->app->base_url.'balance/history');

        return false;
    }

    public function authorize(){
        $package = st('packages', ['id'=>p('pack_id')]);
        $_POST['amount'] = $package->price;
        $total = (int) $_POST["amount"];
        if ($total == "" || !is_numeric($total)) {
            echo '<script>alert("Tutar Alanı Boş olamaz.") </script>';
            exit;
        } elseif ($total < 5 ) {
            echo '<script>alert("Minimum ödeme tutarı 5TL.") </script>';
            exit;
        }

        $method = $this->method;
        if(file_exists(__DIR__.'/'.$method.'.php')){
            $name = 'Ctr\payment\\'.$method;
            $payment = new $name();
            $payment->call();
        }else{
            return false;
        }

        return false;
    }

}



