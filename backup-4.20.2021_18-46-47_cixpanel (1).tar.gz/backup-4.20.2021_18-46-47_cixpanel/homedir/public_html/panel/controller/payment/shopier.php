<?php
namespace Ctr\payment;
class shopier extends paymentGateway {

    public function call(){
        $_POST = p();
        if(!$_POST) exit;
        date_default_timezone_set('Europe/Istanbul');
        $total = strip_tags($_POST["amount"]);
        $total = \func::getAmount($total);


        include __DIR__."/lib/shopier.php"; // SHOPİER APİ DAHİL EDİLDİ

        $shopier = new \_Shopier($this->account->shopier_key, $this->account->shopier_secret);
        $callback_url = $this->app->base_url."payGate?id=shopier"; // Geri Dönüş URL'si
        $u = $this->app->user;

        // ÖDEME YAPAN KİŞİNİN BİLGİLERİ
        $shopier->setBuyer([
            'id' => 23,
            'first_name' => $u->first_name, 'last_name' => $u->last_name, 'email' => $u->email, 'phone' => $u->phoneNumber]);
        // VERİLEN SİPARİŞİN FATURASI
        $shopier->setOrderBilling([
            'billing_address' => 'ADRES - MAHALLE',
            'billing_city' => 'ŞEHİR',
            'billing_country' => 'TR',
            'billing_postcode' => 'POSTA KODU',
        ]);
        // SİPARİŞİ VEREN KİŞİ - ÜSTTEKİ İLE AYNI BİLGİLERİ GİREBİLİRSİNİZ.
        $shopier->setOrderShipping([
            'shipping_address' => 'ADRES - MAHALLE',
            'shipping_city' => 'ŞEHİR',
            'shipping_country' => 'TR',
            'shipping_postcode' => 'POSTA KODU',
        ]);

        $package = st('packages', ['id'=>p('pack_id')]);
        it('order_invoice',[
            //                    "order_id"=>0,
            "user_id"=>$this->app->user->id,
            "total"=>$total,
            "payment_method"=>1,
            "status"=>0,
            "package_id"=>$package->id,
            "package_name"=>$package->name,
            "link_count"=>$package->link_count,
            "created_at"=>date('Y-m-d H:i:s'),
        ]);

        // ÖDEME BÖLÜMÜNE YÖNLENDİRME İŞLEMİ
        die($shopier->run(ld(), $total, $callback_url));

    }

    public function notify(){
        include __DIR__."/lib/shopier.php"; // SHOPİER APİ DAHİL EDİLDİ
        $shopier = new \_Shopier($this->account->shopier_key, $this->account->shopier_secret);
        if(!$shopier->verifyShopierSignature($_POST)) die('gecersiz istek');

        $orderid=p('platform_order_id');
        //Islem basarili oldugunda success yazılarak, Shopier tarafında bildirimin basarili
        //geldigi dogrulanmıs olunur
        $order = st('order_invoice',['id'=>$orderid,'status'=>0]);
        if($order){
            ue('order_invoice',['status'=>1,'id'=>$orderid]);
//            qy('update users set balance = balance + '.$order->total.' where id = "'.$order->user_id.'"');
        }
        echo "success";
    }

}