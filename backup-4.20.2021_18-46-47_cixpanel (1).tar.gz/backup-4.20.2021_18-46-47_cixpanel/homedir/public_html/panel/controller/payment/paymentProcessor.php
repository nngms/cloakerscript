<?php
class paymentProcessor {
    public function processPayment($gateway) {
        //Create the respective object depending upon gateway
        $gateway = getGateway($gateway);
        $response = $gateway->processPayment();
    }
}