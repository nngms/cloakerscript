<?php
/**
 * Bu lisanslı bir yazılımdır. İzinsiz kullanım,dağıtım,kopyalama durumlarında yasal işlem yapılacaktır.
 * Oluşturulma: 20.4.2018
 * Dosya: CaptchaController.php
 * Proje: İlan Yazılımı Pro Version
 * Proje Sahibi: seora.net
 */

namespace Ctr\security;

use Ctr\base;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use Intervention\Image\ImageManagerStatic as Image;

class CaptchaController extends base {

    public function getCaptcha(){
        $this->font_path = __DIR__ . '/fonts/';
        $bg_path = __DIR__ . '/backgrounds/';

        $backgrounds = array(
            $bg_path . '45-degree-fabric.png',
            $bg_path . 'cloth-alike.png',
            $bg_path . 'grey-sandbag.png',
            $bg_path . 'kinda-jean.png',
            $bg_path . 'polyester-lite.png',
            $bg_path . 'stitched-wool.png',
            $bg_path . 'white-carbon.png',
            $bg_path . 'white-wave.png'
        );
        $background = $backgrounds[mt_rand(0, count($backgrounds) -1)];

        $colors = array(
            '#b03060',
            '#666',
            '#1c49a5',
            '#dfb110',
            '#13a71b',
        );
        $this->color = $colors[mt_rand(0, count($colors) -1)];

        $this->angle = mt_rand(0, 8) * (mt_rand(0, 1) == 1 ? -1 : 1);

        $kod = $this->rand_string();
        $_SESSION['captcha'] = $kod;

        $img = Image::make($background)->encode('png');
        $img->text($kod,82,25,function($font) {
            $font->file($this->font_path . 'times_new_yorker.ttf');
            $font->size(32);
            $font->color($this->color);
            $font->align('center');
            $font->valign('top');
            $font->angle($this->angle);
        });

        header('Content-Type: image/png');
        return $img->response();

        return new Response($img->response(),200,['Content-Type'=>'image/png']);
    }

    public function rand_string($minLength=4,$maxLength=6) {
        $chars = "ABCDEFGHJKLMNPRSTUVWXYZabcdefghjkmnprstuvwxyz23456789";
        $str = '';

        $length = mt_rand($minLength, $maxLength);

        $size = strlen( $chars );
        for( $i = 0; $i < $length; $i++ ) {
            $str .= $chars[ rand( 0, $size - 1 ) ];
        }

        return $str;
    }


}