<?php
namespace Ctr;

class orders extends base {

    public function index(){
        $vars=['items'=>sl('order_invoice',['user_id'=>$this->app->user->id])];

        return render('orders',$vars);
    }

    public function admin(){
        $vars=['items'=>sl('order_invoice')];

        return render('orders_admin',$vars,['userInfo'=>function($id){
            $user = st('users',['id'=>$id]);
            return (array)$user;
        }]);
    }

}
