<?php namespace Ctr;

use Symfony\Component\HttpFoundation\Response;

class base{
    public function __construct()
    {
        $this->app = $GLOBALS['app'];
//        $this->request = $this->app->request;
//        $this->input = $this->request->request;
//        $this->par = $this->request->query;
        $this->db = $GLOBALS['db'];

    }

    public function qPage($controller,$action='index',$params=''){
        $target = '\Ctr\\'.$controller;
        if($action!='register' && $action!='registerSave' && $action!='captcha' && $action!='filterServices' && $controller!='resetpassword')
            (new user())->loggedInFilter();

        if($_SERVER['REQUEST_METHOD']=='POST' and $action=='add') $action = 'save';

        if( is_callable( [$target, $action] ) ) {
            $target = new $target($this->app);
            return call_user_func([$target,$action]);
        } else {
            _404();
        }
    }

}