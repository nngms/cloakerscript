<?php
namespace Ctr;

function sanitize_output($buffer) {

    $search = array(
        '/\>[^\S ]+/s',     // strip whitespaces after tags, except space
        '/[^\S ]+\</s',     // strip whitespaces before tags, except space
        '/(\s)+/s',         // shorten multiple whitespace sequences
        '/<!--(.|\s)*?-->/' // Remove HTML comments
    );

    $replace = array(
        '>',
        '<',
        '\\1',
        ''
    );

    $buffer = preg_replace($search, $replace, $buffer);

    return $buffer;
}

class infos extends base {

    public function index(){
        if ( !$this->app->userLib->check()) {
            $user = new user();
            return $user->index();
        }

        $item = st('links',['id'=>g('id')]);

        $blogger = file_get_contents('blogger_template.html');
        $blogger = str_replace('{{ url }}', $this->app->site_url, $blogger);
        $blogger = str_replace('{{ id }}', $item->id, $blogger);
        $html = file_get_contents('html_template.html');
        $html = str_replace('{{ url }}', $this->app->site_url, $html);
        $html = str_replace('{{ id }}', $item->id, $html);

        $vars = [
            'id'=>$item->id,
            'subdomain'=>str_replace('://','://'.$item->source.'.', $this->app->site_url.'index.php'),
            'blogger'=>sanitize_output($blogger),
            'html'=>sanitize_output($html),
        ];

        return render('infos',$vars);
    }

    public function space(){
        require_once("Spaces/spaces.php");
        $spaces = Spaces("M5YWTQZ632MAT7CSIGBN", "964mOsZnH+DjQ5OcoUCw6T8rs27to5p2iWYlQsdLMhY");
        $id = p('id');
        $name = p('name');
        try{
            $spaces->create($name, "nyc3", "public");
        }catch (\Exception $e){
//            print_r($e->getMessage());
            return json_encode(['error'=>'Bu isim daha önce alınmış.']);
        }
        $space = $spaces->space($name, "nyc3");
        $file = file_get_contents($this->app->base_dir."html_template.html");
        $file = str_replace('{{ url }}', $this->app->site_url, $file);
        $file = str_replace('{{ id }}', $id, $file);
        $new_file = $this->app->base_dir."html_template_last.html";
        file_put_contents($new_file, sanitize_output($file));

        $obj = $space->uploadFile($new_file, "index.html", "public");
        return json_encode(['success'=>$obj['ObjectURL']]);

    }

}
