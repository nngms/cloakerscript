<?php
namespace Ctr;
use Ctr\payment\paymentGateway;

class packages extends base {

    public function index(){
        $vars=[];

        return render('packages',$vars);
    }

    public function action(){
        return (new paymentGateway())->authorize();
    }

}
