<?php
namespace Ctr;

class manual extends base {

    public function index(){
        $vars=[];

        return render('manual',$vars);
    }

}
