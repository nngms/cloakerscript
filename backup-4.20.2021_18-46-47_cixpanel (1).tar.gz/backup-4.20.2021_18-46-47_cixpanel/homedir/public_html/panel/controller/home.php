<?php
namespace Ctr;


class home extends base {

    public function index(){
        if ( !$this->app->userLib->check()) {
            $order = new user();
            return $order->index();
        }
        return render('index',['items'=>sl('links',['user_id'=>$this->app->user->id])]);
    }

    public function add(){
        $user_packages = sl('order_invoice',['user_id'=>$this->app->user->id,'status'=>1,'c'=>'and link_count>0']);
        render('add', ['item'=>st('links',['id'=>g('id'),'user_id'=>$this->app->user->id]),'packages'=>$user_packages]);
    }
    
    public function save(){
        $user_package = st('order_invoice',['id'=>p('package'),'user_id'=>$this->app->user->id,'status'=>1,'c'=>'and link_count>0']);
        if(!$user_package)
            return json_encode(['error'=>'Gecersiz paket', 'redirect'=>base_url()]);

        $_POST['user_id']=$this->app->user->id;
        unset($_POST['package']);
        se('links');
        qy('update order_invoice set link_count = link_count - 1 where id = "'.$user_package->id.'"');
        return json_encode(['success'=>'basarili', 'redirect'=>base_url()]);
    }

    public function remove(){
        dy('links',g('id'));
        return json_encode(['success'=>'basarili', 'redirect'=>base_url()]);

    }

    public function captcha(){
        $a= new security\CaptchaController;
        return $a->getCaptcha();
    }


}
